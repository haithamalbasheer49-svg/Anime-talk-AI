package com.animetalk.ai

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Ink = Color(0xFF090D1B)
private val Panel = Color(0xFF151C32)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF38BDF8)
private val Gold = Color(0xFFFFC857)

data class Persona(val name: String, val role: String, val level: String, val emoji: String, val color: Color)
data class ChatLine(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPAN
        }
        setContent { AnimeTalkApp(onSpeak = { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "jp") }) }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun AnimeTalkApp(onSpeak: (String) -> Unit) {
    var tab by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf(Persona("Hana", "رفيقة التعلم", "مبتدئ", "🌸", Violet)) }
    val personas = listOf(
        Persona("Hana", "رفيقة التعلم", "مبتدئ", "🌸", Violet),
        Persona("Ren", "مدرب المحادثة", "متوسط", "⚔️", Cyan),
        Persona("Akira", "المعلم الهادئ", "متقدم", "🎴", Gold)
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, secondary = Cyan, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf(Triple("home", "الرئيسية", Icons.Default.Home),
                        Triple("learn", "التعلم", Icons.Default.School),
                        Triple("chat", "المحادثة", Icons.Default.Chat),
                        Triple("profile", "ملفي", Icons.Default.Person)).forEach { item ->
                        NavigationBarItem(
                            selected = tab == item.first,
                            onClick = { tab = item.first },
                            icon = { Icon(item.third, null) },
                            label = { Text(item.second) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan, selectedTextColor = Cyan,
                                indicatorColor = Violet.copy(alpha = .18f),
                                unselectedIconColor = Color.LightGray,
                                unselectedTextColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "home" -> HomeScreen(personas, onSelect = { selected = it; tab = "chat" }, onLearn = { tab = "learn" })
                    "learn" -> LearnScreen()
                    "chat" -> ChatScreen(selected, onSpeak)
                    else -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(personas: List<Persona>, onSelect: (Persona) -> Unit, onLearn: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("こんにちは！", color = Cyan, fontSize = 14.sp)
                    Text("مرحباً بك في AnimeTalk", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("تعلّم اليابانية… محادثة بعد محادثة", color = Color.LightGray, fontSize = 13.sp)
                }
                Box(Modifier.size(48.dp).background(Violet.copy(.2f), CircleShape), Alignment.Center) {
                    Text("あ", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF32205C), Color(0xFF123B59))), RoundedCornerShape(22.dp)).padding(18.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("رحلتك تبدأ من هنا", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("تدرّب يومياً مع شخصيات ذكية وصمّم عادة تعلم ثابتة.", color = Color.White.copy(.8f))
                    Button(onClick = onLearn, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
                        Text("ابدأ أول درس", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { SectionTitle("اختر رفيقك") }
        items(personas) { p ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onSelect(p) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).background(p.color.copy(.2f), CircleShape), Alignment.Center) {
                    Text(p.emoji, fontSize = 29.sp)
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(p.role, color = Color.LightGray, fontSize = 13.sp)
                    Text("المستوى: ${p.level}", color = Cyan, fontSize = 11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Cyan)
            }
        }
        item {
            SectionTitle("تقدمك اليوم")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("0", "كلمات جديدة", Modifier.weight(1f))
                StatCard("0 دقيقة", "وقت التعلم", Modifier.weight(1f))
                StatCard("0", "أيام متتالية", Modifier.weight(1f))
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable fun SectionTitle(s: String) { Text(s, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
@Composable fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(value, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Color.LightGray, fontSize = 11.sp)
    }
}

@Composable
fun LearnScreen() {
    val lessons = listOf(
        Triple("ひらがな Hiragana", "تعلم الحروف الأساسية وطريقة نطقها", "مبتدئ"),
        Triple("カタカナ Katakana", "الحروف المستخدمة للكلمات الأجنبية", "مبتدئ"),
        Triple("عبارات يومية", "التحية والتعارف والطلب في المطاعم", "مبتدئ"),
        Triple("مفردات Kanji", "مقدمة في الرموز ومعانيها", "متوسط")
    )
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("مسار التعلم", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("اختر درساً وابدأ بالتدريب", color = Color.LightGray) }
        items(lessons) { lesson ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text(lesson.first, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(lesson.second, color = Color.LightGray, modifier = Modifier.padding(vertical = 7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(lesson.third, color = Gold, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("قريباً", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ChatScreen(persona: Persona, onSpeak: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var apiUrl by remember { mutableStateOf("http://10.0.2.2:3000/chat") }
    val messages = remember { mutableStateListOf(ChatLine("こんにちは！ أنا ${persona.name}. لنبدأ بتعلم اليابانية. كيف حالك؟", false)) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(persona.emoji, fontSize = 30.sp)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text("محادثة مع ${persona.name}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("مساعد ياباني ذكي • ${persona.level}", color = Cyan, fontSize = 12.sp)
            }
            Icon(Icons.Default.VolumeUp, null, tint = Cyan, modifier = Modifier.clickable { onSpeak("こんにちは。日本語を勉強しましょう。") })
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 300.dp).background(if (msg.fromUser) Violet.copy(.28f) else Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Text(msg.text, color = Color.White)
                        if (!msg.fromUser) Text("اضغط للاستماع", color = Cyan, fontSize = 10.sp, modifier = Modifier.clickable { onSpeak(msg.text) }.padding(top = 5.dp))
                    }
                }
            }
            if (busy) item { Text("يكتب الآن…", color = Cyan) }
        }
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(10.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), decorationBox = { inner ->
                if (input.isEmpty()) Text("اكتب باليابانية أو العربية…", color = Color.Gray)
                inner()
            })
            IconButton(onClick = {
                val prompt = input.trim()
                if (prompt.isNotEmpty() && !busy) {
                    messages.add(ChatLine(prompt, true)); input = ""; busy = true
                    scope.launch {
                        val reply = requestAi(apiUrl, prompt, persona.name)
                        messages.add(ChatLine(reply, false)); busy = false
                    }
                }
            }, enabled = !busy) { Icon(Icons.Default.Send, null, tint = Cyan) }
        }
        Text("للتشغيل الفعلي: شغّل الخادم الخلفي واضبط عنوانه في إعدادات المشروع.", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 7.dp))
    }
}

suspend fun requestAi(endpoint: String, prompt: String, persona: String): String = withContext(Dispatchers.IO) {
    try {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 12000; readTimeout = 30000
            doOutput = true; setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().put("message", prompt).put("character", persona).toString()
        conn.outputStream.use { it.write(body.toByteArray()) }
        val response = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        JSONObject(response).optString("reply", "لم يصل رد من الخادم.")
    } catch (e: Exception) {
        "تعذر الاتصال بخادم الذكاء الاصطناعي. تأكد من تشغيل الخادم وضبط عنوانه. ( ${e.localizedMessage ?: "Network error"} )"
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ملفي الشخصي", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.size(76.dp).background(Violet.copy(.2f), CircleShape), Alignment.Center) { Text("侍", color = Cyan, fontSize = 36.sp) }
        Text("متعلم جديد", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("المستوى الحالي: مبتدئ • نقاط الخبرة: 0 XP", color = Color.LightGray)
        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Panel)
        Text("سيتم حفظ تقدمك وربطه بحسابك في مرحلة قاعدة البيانات.", color = Color.LightGray)
    }
}
