import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ status: "ok", app: "AnimeTalk AI" }));

app.post("/chat", async (req, res) => {
  try {
    const { message, character = "Hana" } = req.body ?? {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "message is required" });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI server is not configured" });
    }
    const persona = {
      Hana: "You are Hana, a cheerful and patient Japanese conversation tutor.",
      Ren: "You are Ren, a confident Japanese speaking coach who encourages practical conversation.",
      Akira: "You are Akira, a calm advanced Japanese tutor who explains nuance precisely."
    }[character] ?? "You are a friendly Japanese language tutor.";

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: `${persona}
Teach Japanese to an Arabic-speaking learner. Reply primarily in simple Japanese, then give a concise Arabic translation and correction when useful. Include romaji for beginner-level Japanese. Be encouraging and keep replies focused.` },
          { role: "user", content: message }
        ],
        temperature: 0.7
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: data.error?.message || "AI provider error" });
    res.json({ reply: data.choices?.[0]?.message?.content || "لم أتمكن من إنشاء رد." });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`AnimeTalk AI server listening on ${port}`));
